var express=require("express")
var app=  express()

app.get("/",function(request,response){
    response.send("Hello World!!!! node app is running...")
})

app.listen("3000",function(){
    console.log("server is running on 3000")
})